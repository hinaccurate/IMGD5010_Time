let Sunrise;
let redVal = 0;
let blueVal = 0;

function preload() {
  Sunrise = loadSound('assets/morning.mp3');
}

function setup() {
  createCanvas(400, 300);
  // play Morning MP3
  Sunrise.play(); 
}

function draw() {
  background(redVal, 2, blueVal);
  drawSun();
  goodmorning();
  if (millis() < 13000) {
    redVal += 0.3;
    blueVal += 0.1;
    }
}

function drawSun(){
  sunriseY = frameCount/5;
    fill("#fab802");
    translate(0,350,0);
    noStroke();
    circle(width/2, sunriseY, frameCount)
    filter(BLUR,2)
  }

function goodmorning(){
  if (millis() > 13000){
    noLoop();
  } 
}